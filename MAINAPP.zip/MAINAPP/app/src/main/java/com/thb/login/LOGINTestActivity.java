package com.thb.login;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.thb.app.APPMainActivity;
import com.thb.app.R;
import com.thb.qr.QRMainActivity;
import com.thb.ui.JellyInterpolator;
import com.thb.ws.TestActivity;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class LOGINTestActivity extends AppCompatActivity implements View.OnClickListener{

    private String usernameCheck;
    private String passwordCheck;
    private String companyCheck;


    private Spinner spinner_company;
    private EditText edit_username;
    private EditText edit_password;
    private CheckBox check_memory;

    private int itemNo=0;
    private SharedPreferences sp;
    private SharedPreferences.Editor editor;

    private Handler mHandler;
    private boolean isConn=false;
    private URL url;
    private HttpURLConnection conn=null;


    private TextView mBtn;
    private View progress;
    private View mInputLayout;
    private float mWidth,mHeight;
    private LinearLayout mUsername,mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
       // requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login_test);
        initView();
        initSpinner();
        init();
    }

    private void initView(){
        mBtn=findViewById(R.id.test_text);
        progress=findViewById(R.id.test_progress);
        mInputLayout=findViewById(R.id.test_input);
        mUsername=findViewById(R.id.login_linear1);
        mPassword=findViewById(R.id.login_linear2);

        spinner_company=findViewById(R.id.input_spinner);
        edit_username=findViewById(R.id.input_username);
        edit_password=findViewById(R.id.input_password);
        check_memory=findViewById(R.id.test_checkbox);

        mBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        mWidth=mBtn.getMeasuredWidth();
        mHeight=mBtn.getMeasuredHeight();
        mUsername.setVisibility(View.INVISIBLE);
        mPassword.setVisibility(View.INVISIBLE);

        inputAnimator(mInputLayout,mWidth,mHeight);

    }

    public void inputAnimator(final View v,float w,float h){
        AnimatorSet set=new AnimatorSet();
        ValueAnimator animator=ValueAnimator.ofFloat(0,w);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                float value=(Float)valueAnimator.getAnimatedValue();
                ViewGroup.MarginLayoutParams params=(ViewGroup.MarginLayoutParams)
                        v.getLayoutParams();
                params.leftMargin=(int)value;
                params.rightMargin=(int)value;
                v.setLayoutParams(params);
            }
        });

        ObjectAnimator animator2 = ObjectAnimator.ofFloat(mInputLayout,"scaleX",1f,0.5f);
        set.setDuration(200);
        set.setInterpolator(new AccelerateDecelerateInterpolator());
        set.playTogether(animator,animator2);
        set.start();
        set.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @Override
            public void onAnimationEnd(Animator animator) {

                progress.setVisibility(View.VISIBLE);
                progressAnimator(progress);
                mInputLayout.setVisibility(View.INVISIBLE);
                //startActivity(new Intent(LOGINTestActivity.this, TestActivity.class));


            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });
    }

    private void progressAnimator(final View v){

        PropertyValuesHolder animator=PropertyValuesHolder.ofFloat("scaleX",0.5f,1f);
        PropertyValuesHolder animator2=PropertyValuesHolder.ofFloat("scaleY",0.5f,1f);
        ObjectAnimator animator3=ObjectAnimator.ofPropertyValuesHolder(v,animator,animator2);
        animator3.setDuration(500);
        animator3.setInterpolator(new JellyInterpolator());
        animator3.start();
        animator3.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
                login();
            }

            @Override
            public void onAnimationEnd(Animator animator) {


            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });
    }

    public void login(){

        usernameCheck=edit_username.getText().toString().trim();
        passwordCheck=edit_password.getText().toString().trim();
        companyCheck=spinner_company.getItemAtPosition(itemNo).toString();
        //Toast.makeText(getApplicationContext(),company_check,Toast.LENGTH_LONG).show();


        if(usernameCheck.equals("zhou")&&passwordCheck.equals("123456")&&companyCheck.equals("191")){
            if(check_memory.isChecked()){
                editor.putString("info_username",usernameCheck);
                editor.putString("info_password",passwordCheck);
                //editor.putString("info_company",itemNo);
                //editor.putString("info_company",itemNo+"");
                editor.commit();
            }else{
                editor.remove("info_username");
                editor.remove("info_password");
                //editor.remove("info_company");
                editor.commit();
            }

            Toast.makeText(getApplicationContext(),"登陆成功", Toast.LENGTH_SHORT).show();
            //startActivity(new Intent(LOGINMainActivity.this,APPMainActivity.class));


            Bundle bundle=new Bundle();
            bundle.putString("usernameCheck",usernameCheck);
            bundle.putString("passwordCheck",passwordCheck);
            bundle.putString("companyCheck",companyCheck);
            Intent intent=new Intent(LOGINTestActivity.this, APPMainActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);


        }else{
            editor.remove("info_username");
            editor.remove("info_password");
            //editor.remove("info_company");
            editor.commit();
            Toast.makeText(getApplicationContext(),"登陆失败", Toast.LENGTH_SHORT).show();

        }
    }

    public void init(){

        sp=getSharedPreferences("info",MODE_PRIVATE);
        editor=sp.edit();

        String username=sp.getString("info_username","");
        String password=sp.getString("info_password","");

        if(username.equals("") || password.equals("")){
            check_memory.setChecked(false);
        }else{
            edit_username.setText(username);
            edit_password.setText(password);
            check_memory.setChecked(true);
        }
    }

    /**
     * 初始化Spinner控件
     */

    public void initSpinner(){

        //建立数据源
        final String[] spinner_items=getResources().getStringArray(R.array.spinnerItems);
        //建立adapter绑定数据源
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item,spinner_items);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //绑定控件
        spinner_company.setAdapter(arrayAdapter);
        spinner_company.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] spinner_items = getResources().getStringArray(R.array.spinnerItems);
                itemNo=i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    /**
     * ping服务器测试是否连接
     * @return
     */
    public boolean isWebConn(){

        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    url=new URL("http://192.168.30.49");
                    conn=(HttpURLConnection)url.openConnection();
                    conn.setConnectTimeout(1000*5);
                    if(conn.getResponseCode()==200){
                        isConn=true;
                    }
                }catch (MalformedURLException e){
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();

        return isConn;
    }
}
