package com.thb.ws;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.util.HashMap;

/**
 * Created by sea79 on 2017/11/2.
 */

public class WSXMLOperator {
    /*
    public static HashMap<String,String> XML2HashMap(String xml)throws Exception{
        HashMap<String,String> in_hashmap=new HashMap<String, String>();

        //XML解析工厂
        XmlPullParserFactory factory=XmlPullParserFactory.newInstance();
        //
        XmlPullParser parser=factory.newPullParser();

    }
    */
}
