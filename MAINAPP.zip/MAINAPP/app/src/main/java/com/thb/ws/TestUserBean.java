package com.thb.ws;

/**
 * Created by sea79 on 2017/10/26.
 */

public class TestUserBean {
    private String id;
    private String account;
    private String password;
    private String barcode;

    public String convertString(){
        return "UserBean [account="+account+",password="+password+",id="+id+",barcode="+barcode+"]";
    }

    public TestUserBean(String account,String password,String id){
        super();
        this.account = account;
        this.password = password;
        this.id=id;
    }

    public TestUserBean(){

    }

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getAccount(){
        return account;
    }

    public void setAccount(String account){
        this.account = account;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password = password;
    }

    public String getBarcode(){
        return barcode;
    }

    public void setBarcode(String barcode){
        this.barcode=barcode;
    }
}