package com.thb.ws;

import android.util.Log;

import com.thb.app.APPMainActivity;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.MarshalBase64;
import org.ksoap2.serialization.MarshalDate;
import org.ksoap2.serialization.MarshalFloat;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.kxml2.kdom.Element;
import org.kxml2.kdom.Node;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Webservice标准：SOAP1.2+Json,每次请求服务需在报文头添加权限信息;
 * Created by sea79 on 2017/11/1.
 */

public class BaanSoapService {
    //DEBUG_TAG
    final static String DEBUG_TAG = "BaanSoapService";

    //activition
    private HashMap<String,String> activationMap=new HashMap<>();

    //WebService三要素
    final static String URL = "http://192.168.9.91/BaanWebService/BaanWebService.asmx";
    final static String NAMESPACE = "http://tempuri.org/";
    final static String METHOD_NAME = "GetBOM";

    final static String UR="http://192.168.30.62:18808/WebService.asmx";
    final static String NS="http://tempuri.org/";


    /**
     * 输入String返回JSON
     * @param activitionMap SOAP报文头传递验证信息
     * @param paramsMap SOAP报文体传递参数
     * @param methodStr 方法名
     * @return resultJson 返回Json
     */
    public String CallWSInSimple(HashMap<String,String> activitionMap,HashMap<String,String> paramsMap,String methodStr) {
        //接受参数
        String resultJson = "";

        //1.HttpTransportSE对象传输URL,设置响应时间
        HttpTransportSE ht = new HttpTransportSE(URL, 1000);
        ht.debug = true;
        //ps1:soap header进行每项方法的调用权限验证

        Element[] header=new Element[1];
        header[0]=new Element().createElement(NAMESPACE,"Activation");

        Element username=new Element().createElement(NAMESPACE,"username");
        username.addChild(Node.TEXT,activitionMap.get("username"));
        header[0].addChild(Node.ELEMENT,username);

        Element password=new Element().createElement(NAMESPACE,"password");
        password.addChild(Node.TEXT,activitionMap.get("password"));
        header[0].addChild(Node.ELEMENT,password);

        Element company=new Element().createElement(NAMESPACE,"company");
        company.addChild(Node.TEXT,activitionMap.get("company"));
        header[0].addChild(Node.ELEMENT,company);

        //2.SoapObject对象指定命名空间及方法名
        SoapObject request = new SoapObject(NAMESPACE, methodStr);

        //3.设置传入参数
        Iterator iter = paramsMap.entrySet().iterator();
            while (iter.hasNext()) {
                HashMap.Entry localEntry = (HashMap.Entry) iter.next();
                request.addProperty((String) localEntry.getKey(), localEntry.getValue());
            }

        //4.生成调用Webservice方法的SOAP请求信息。
        // 该信息由SoapSerializationEnvelope对象描述
        // 是否为C#程序
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
        envelope.bodyOut = request;
        envelope.dotNet = true;
        //set headerout
        envelope.headerOut=header;

        //5.使用call方法调用WebService
        Log.e("&&&&&&&&&&&&&&&&&&",request.toString());

        try{
            ht.call(null, envelope);
            //6.返回Json
            if (envelope.getResponse() != null) {
                SoapObject result= (SoapObject) envelope.bodyIn;
                resultJson = result.getPropertyAsString(methodStr+"Result");
                Log.e("---收到的回复---", resultJson.toString());
                }
            }catch (IOException e) {
            resultJson = e.getMessage();
            //Log.e("---IO错误---", e.getMessage());
        }catch (XmlPullParserException e) {
            resultJson=e.getMessage();
            //Log.e("---XML解析错误---", e.getMessage());
        }catch (Exception e){
            resultJson=e.getMessage();
            //Log.e("---exception---",e.getMessage());
        }
        return resultJson;

     }

    /**
     * 输入复杂类型
     * <entity>
     *     <String></String>
     *     <String></String>
     * </entity>
     * 返回JSON
     * @param
     * @param paramsMap
     * @param methodStr
     * @return
     */
    public String CallWSInComplex(HashMap<String,String> paramsMap,String methodStr) {
        //接受参数
        String resultJson = "";

        //1.HttpTransportSE对象传输URL,设置响应时间
        HttpTransportSE ht = new HttpTransportSE(UR, 1000);
        ht.debug = true;
        //ps1:soap header进行权限验证,自动

        /*
        Element[] header=new Element[1];
        header[0]=new Element().createElement(NAMESPACE,"Activation");

        Element username=new Element().createElement(NAMESPACE,"username");
        username.addChild(Node.TEXT,activitionMap.get("username"));
        header[0].addChild(Node.ELEMENT,username);

        Element password=new Element().createElement(NAMESPACE,"password");
        password.addChild(Node.TEXT,activitionMap.get("password"));
        header[0].addChild(Node.ELEMENT,password);

        Element company=new Element().createElement(NAMESPACE,"company");
        company.addChild(Node.TEXT,activitionMap.get("company"));
        header[0].addChild(Node.ELEMENT,company);
        */

        //2.SoapObject对象指定命名空间及方法名
        SoapObject request = new SoapObject(NS, methodStr);

        //3.设置传入参数
        //
        //SoapObject entity=new SoapObject(NAMESPACE,methodStr);

        /*
        Iterator iter = paramsMap.entrySet().iterator();
            while (iter.hasNext()) {
                    HashMap.Entry localEntry = (HashMap.Entry) iter.next();
                    request.addProperty((String) localEntry.getKey(), localEntry.getValue());
        */



        ReportOrdersCompletedMD md=new ReportOrdersCompletedMD();
        md.setProperty(0,paramsMap.get("Unique"));
        md.setProperty(1,paramsMap.get("ProductionOrder"));
        md.setProperty(2,paramsMap.get("QuantityToDeliver"));
        md.setProperty(3,paramsMap.get("LotCode"));

        PropertyInfo pi=new PropertyInfo();
        pi.setName("entity");
        pi.setValue(md);
        pi.setType(md.getClass());

        request.addProperty(pi);

        //4.生成调用Webservice方法的SOAP请求信息。
        // 该信息由SoapSerializationEnvelope对象描述
        // 是否为C#程序
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.bodyOut = request;

        envelope.dotNet = true;

        //set headerout
        //envelope.headerOut=header;

        //complexType only

        envelope.addMapping(NS,"ReportOrdersCompletedMD",ReportOrdersCompletedMD.class);

        //Log.e("&&&&&&&&&&&&&&&&&&",header.toString());
        Log.e("******************",request.toString());

        try{
            ht.call(NS+methodStr, envelope);
            //6.返回Json
            if (envelope.getResponse() != null) {
                SoapObject result= (SoapObject) envelope.bodyIn;
                resultJson = result.getPropertyAsString(methodStr+"Result");
                Log.d("---收到的回复---", resultJson.toString());
            }else {
                Log.e("!!!!!!!!!!!","没有返回信息");
            }
        }
        /*
        catch (IOException e) {
            resultJson = e.getMessage();
            Log.e("---IO错误---", e.getMessage());
        }catch (XmlPullParserException e) {
            e.getMessage();
            Log.e("---XML解析错误---", e.getMessage());
        }
     */
        catch (Exception e){
            e.getMessage();
            Log.e("---exception---",e.getMessage());
        }

        return resultJson;
    }

    public String CallBaanWS(HashMap<String,String> activationMap,HashMap<String,String> paramsMap,String methodStr) {
        //接受参数
        String resultJson = "";

        //1.HttpTransportSE对象传输URL,设置响应时间
        HttpTransportSE ht = new HttpTransportSE(URL, 1000);
        ht.debug = true;
        //ps1:soap header进行权限验证,自动


        Element[] header=new Element[1];
        header[0]=new Element().createElement(NAMESPACE,"Activation");

        Element username=new Element().createElement(NAMESPACE,"username");
        username.addChild(Node.TEXT,activationMap.get("username"));
        header[0].addChild(Node.ELEMENT,username);

        Element password=new Element().createElement(NAMESPACE,"password");
        password.addChild(Node.TEXT,activationMap.get("password"));
        header[0].addChild(Node.ELEMENT,password);

        Element company=new Element().createElement(NAMESPACE,"company");
        company.addChild(Node.TEXT,activationMap.get("company"));
        header[0].addChild(Node.ELEMENT,company);


        //2.SoapObject对象指定命名空间及方法名
        SoapObject request = new SoapObject(NAMESPACE, methodStr);

        //3.设置传入参数
        //
        //SoapObject entity=new SoapObject(NAMESPACE,methodStr);

        /*
        Iterator iter = paramsMap.entrySet().iterator();
            while (iter.hasNext()) {
                    HashMap.Entry localEntry = (HashMap.Entry) iter.next();
                    request.addProperty((String) localEntry.getKey(), localEntry.getValue());
        */



        ReportOrdersCompletedMD md=new ReportOrdersCompletedMD();
        md.setProperty(0,paramsMap.get("Unique"));
        md.setProperty(1,paramsMap.get("ProductionOrder"));
        md.setProperty(2,paramsMap.get("QuantityToDeliver"));
        //md.setProperty(3,paramsMap.get("LotCode"));

        PropertyInfo pi=new PropertyInfo();
        pi.setName("entity");
        pi.setValue(md);
        pi.setType(md.getClass());

        request.addProperty(pi);

        //4.生成调用Webservice方法的SOAP请求信息。
        // 该信息由SoapSerializationEnvelope对象描述
        // 是否为C#程序
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);

        envelope.bodyOut = request;

        envelope.dotNet = true;
        //envelope.dotNet=false;

        //set headerout
        envelope.headerOut=header;

        //complexType only

        envelope.addMapping(NAMESPACE,"ReportOrdersCompletedMD",ReportOrdersCompletedMD.class);

        Log.e("&&&&&&&&&&&&&&&&&&",header.toString());
        Log.e("******************",request.toString());

        try{
            ht.call("http://tempuri.org/ReportOrdersCompleted", envelope);
            //6.返回Json
            //if (envelope.getResponse() != null) {
                //SoapObject result= (SoapObject) envelope.bodyIn;
               // resultJson=result.getPropertyAsString("ReportOrdersCompletedResult");
                //resultJson=result.toString();
                //Log.e("---收到的回复---", result.toString());
            //SoapPrimitive soapPrimitive=(SoapPrimitive)envelope.bodyIn;
            Object object=envelope.getResponse();
            resultJson=object.toString();
                Log.e("~~~~~~~~~~",resultJson);
            //}else {
            //    Log.e("!!!!!!!!!!!","没有返回信息");
           // }
        }
        /*
        catch (IOException e) {
            resultJson = e.getMessage();
            Log.e("---IO错误---", e.getMessage());
        }catch (XmlPullParserException e) {
            e.getMessage();
            Log.e("---XML解析错误---", e.getMessage());
        }
     */
        catch (Exception e){
            e.getMessage();
            //Log.e("---exception---",e.getMessage());
        }

        return resultJson;
    }

    public void setActivationMap(String username,String password,String company){
        activationMap.put("username",username);
        activationMap.put("password",password);
        activationMap.put("company",company);
    }

    public HashMap<String, String> getActivationMap(){
        return activationMap;
    }
}
