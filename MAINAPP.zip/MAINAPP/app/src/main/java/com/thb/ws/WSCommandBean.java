package com.thb.ws;

public class WSCommandBean {
    private String status;
    private String errmsg;
		
	public String getStatus(){
		return status;
	}
	
	public void setStatus(String status){
		this.status = status;
	}
	
	public String getErrmsg(){
		return errmsg;
	}
	
	public void setErrmsg(String errmsg){
		this.errmsg = errmsg;
	}
}
