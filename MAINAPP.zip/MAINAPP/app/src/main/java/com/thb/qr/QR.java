package com.thb.qr;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.rscja.utility.StringUtility;
import com.zebra.adc.decoder.Barcode2DWithSoft;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by sea79 on 2017/11/20.
 */

public class QR {
    //扫码api
    public Barcode2DWithSoft mReader;

    private Context mContext;

    private String initCode;
    int successCount=0;
    int failCount=0;
    int errorCount=0;
    private Thread thread;
    private boolean isThreadStop=true;
    private boolean isCurrFrag=false;
    private boolean isContinue=false;
    private String resultStr=null;

    private ArrayList<String> allParamsList=new ArrayList<>();
    private HashMap<String,String> paramsMap=new HashMap<>();
    private HashMap<String,String> activationMap=new HashMap<>();

    public void QRinit(){
        try{
            mReader=Barcode2DWithSoft.getInstance();
            Toast.makeText(mContext,"扫描功能已就绪",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(mContext,e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    public Barcode2DWithSoft.ScanCallback mScanCallback=new Barcode2DWithSoft.ScanCallback() {
        @Override
        public void onScanComplete(int i, int length, byte[] data) {

            if (isCurrFrag) {
                return;
            }

            if (length < 1) {
                resultStr = "扫描失败" + "\n";
                return;
            }else{
                resultStr="扫描成功"+"\n";
                String barCode = new String(data);
                allParamsList.add(barCode.trim());
            }

            mReader.stopScan();
        }
    };

    private void doDecode(boolean isContinue,int interval){

        if(mReader != null){
            mReader.setScanCallback(mScanCallback);
        }

        if(isThreadStop){

            if(isContinue){
                isThreadStop=false;
            }

            thread=new DecodeThread(isContinue,interval);
            thread.start();

        }else{
            isThreadStop=true;
        }
    }

    private class DecodeThread extends Thread{
        private boolean isContinue=false;
        private long sleepTime=1000;

        public DecodeThread(boolean isContinue,int sleep){
            this.isContinue=isContinue;
            this.sleepTime=sleep;
        }

        @Override
        public void run(){
            super.run();

            do{
                mReader.scan();

                if(isContinue){
                    try{
                        Thread.sleep(sleepTime);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }while (isContinue&&!isThreadStop);
        }
    }

    public class InitTask extends AsyncTask<String,Integer,Boolean> {
        ProgressDialog myDialog;

        @Override
        protected Boolean doInBackground(String...params){
            boolean result=false;

            if(mReader!=null){
                result=mReader.open(mContext);
                if(result){
                    mReader.setParameter(324,1);
                    mReader.setParameter(300,0);
                    mReader.setParameter(361,0);
                }
            }
            return result;
        }

        @Override
        protected void onPostExecute(Boolean result){
            super.onPostExecute(result);
            myDialog.cancel();

            if(!result){
                Toast.makeText(mContext,"初始化失败",Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onPreExecute(){

            super.onPreExecute();
            myDialog=new ProgressDialog(mContext);
            myDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            myDialog.setMessage("初始化中...");
            myDialog.setCanceledOnTouchOutside(false);
            myDialog.show();
        }
    }

    public void doScan(){

    }
}
