package com.thb.app;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TableLayout;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.thb.ws.BOMBean;
import com.thb.ws.BaanJsonOperator;
import com.thb.ws.BaanSoapService;
import com.thb.ws.BeanListAdapter;
import com.zebra.adc.decoder.Barcode2DWithSoft;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link APPTab1Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class APPTab1Fragment extends Fragment {

    private ListView listView;
    private BeanListAdapter mAdapter;
    private Barcode2DWithSoft mReader;

    private String scanResult;

    @ViewInject(R.id.tab1_table_edit1)
    private EditText edit1;
    @ViewInject(R.id.tab1_table_edit2)
    private EditText edit2;
    @ViewInject(R.id.tab1_table_edit3)
    private EditText edit3;
    @ViewInject(R.id.tab1_table_edit4)
    private EditText edit4;
    @ViewInject(R.id.tab1_table_edit5)
    private EditText edit5;
    @ViewInject(R.id.tab1_table_edit6)
    private EditText edit6;
    @ViewInject(R.id.tab1_table_edit7)
    private EditText edit7;
    @ViewInject(R.id.tab1_table_edit8)
    private EditText edit8;
    @ViewInject(R.id.tab1_table_edit9)
    private EditText edit9;
    @ViewInject(R.id.tab1_table_edit10)
    private EditText edit10;
    @OnClick(R.id.tab1_button1)
    public void scanClick(View v){

        doScan();
        doDecode();

    }
    @OnClick(R.id.tab1_button2)
    public void callClick(View v){
        doCall();
    }

    @OnClick(R.id.tab1_button3)
    public void clearClick(View v){
        doClear();
    }

    @OnClick(R.id.tab1_button4)
    public void scanAllClick(View v){

    }

    @OnClick(R.id.tab1_button5)
    public void callAllClick(View v){

    }

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public APPTab1Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment APPTab1Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static APPTab1Fragment newInstance(String param1, String param2) {
        APPTab1Fragment fragment = new APPTab1Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectLeakedSqlLiteObjects().detectLeakedClosableObjects().penaltyLog().penaltyDeath().build());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_app_tab1,container,false);
        listView=view.findViewById(R.id.tab1_list);
        View listHeader=LayoutInflater.from(getContext()).inflate(R.layout.beanlist_header,null,true);
        listView.addHeaderView(listHeader);
        ViewUtils.inject(this,view);

        return view;

    }

    // TODO: Rename method, update argument and hook method into UI event

    public void initView(){

    }

    @Override
    public void onDetach() {
        super.onDetach();


    }

    public void doScan(){

        mReader=Barcode2DWithSoft.getInstance();
        mReader.open(getActivity());
        mReader.setParameter(324,1);
        mReader.setParameter(300,0);
        mReader.setParameter(361,0);
        mReader.scan();
    }

    public Barcode2DWithSoft.ScanCallback mScanCallback=new Barcode2DWithSoft.ScanCallback() {
        @Override
        public void onScanComplete(int i, int i1, byte[] bytes) {


            if(i1<1){
                edit1.setText("扫描失败");
            }else {
                scanResult=new String(bytes);
                edit1.setText(scanResult);
            }
            mReader.stopScan();
        }
    };

    public void doDecode(){
        mReader.setScanCallback(mScanCallback);
    }

    public void doCall(){
        String method="GetBOM";
        HashMap<String,String> out_headhashmap=new HashMap<String,String>();
        HashMap<String,String> out_bodyhashmap=new HashMap<>();
        ArrayList<BOMBean> BOMBeanList;


        out_headhashmap.put("username",((APPMainActivity)getActivity()).getUsername());
        out_headhashmap.put("password",((APPMainActivity)getActivity()).getPassword());
        out_headhashmap.put("company",((APPMainActivity)getActivity()).getCompany());

        out_bodyhashmap.put("mitem",edit1.getText().toString().trim());

        //out_hashmap.put("byProvinceName","河南");

        Log.e("******body******",out_bodyhashmap.get("mitem"));
        Log.e("******head******",out_headhashmap.get("username"));
        Log.e("******head******",out_headhashmap.get("password"));
        Log.e("******head******",out_headhashmap.get("company"));



            BaanSoapService service=new BaanSoapService();
            String resultStr=service.CallWSInSimple(out_headhashmap,out_bodyhashmap,method);
            BOMBeanList=new BaanJsonOperator().ListJson2ListBean(resultStr);
            if(BOMBeanList.isEmpty()){

            }else{
                BOMBean bean=BOMBeanList.get(1);
                edit2.setText(bean.getT$MITM().trim());
                edit3.setText(bean.getT$UNOM().trim());
                edit4.setText(bean.getT$PONO().trim());
                edit5.setText(bean.getT$SITM().trim());
                edit6.setText(bean.getT$QANA().trim());
                edit7.setText(bean.getT$SCPF().trim());
                edit8.setText(bean.getT$SCPQ().trim());
                edit9.setText(bean.getT$INDT().trim());
                edit10.setText(bean.getT$EXDT().trim());

                 mAdapter=new BeanListAdapter(getActivity(),BOMBeanList);
                 listView.setAdapter(mAdapter);
            }

        }



    public void doClear(){
        edit1.setText("");
        edit2.setText("");
        edit3.setText("");
        edit4.setText("");
        edit5.setText("");
        edit6.setText("");
        edit7.setText("");
        edit8.setText("");
        edit9.setText("");
        edit10.setText("");
    }
    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */



}

