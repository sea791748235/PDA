package com.thb.ws;

/**
 * Created by sea79 on 2017/11/13.
 */

public class EntityBean {
    private String Unique;
    private String ProductionOrder;
    private String QuantityToDeliver;
    private String LotCode;

    public String getUnique(){
        return Unique;
    }

    public void setUnique(String Unique){
        this.Unique=Unique;
    }

    public String getProductionOrder(){
        return ProductionOrder;
    }

    public void setProductionOrder(String ProductionOrder){
        this.ProductionOrder=ProductionOrder;
    }

    public String getQuantityToDeliver(){
        return QuantityToDeliver;
    }

    public void setQuantityToDeliver(String QuantityToDeliver){
        this.QuantityToDeliver=QuantityToDeliver;
    }

    public String getLotCode(){
        return LotCode;
    }

    public void setLotCode(String LotCode){
        this.LotCode=LotCode;
    }
}
