package com.thb.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Created by sea79 on 2017/10/18.
 */

public class APPBaseFragment extends FrameLayout {

    private ScrollView base_scroll;
    private TextView table_text1,table_text2,table_text3,table_text4,table_text5,
            table_text6,table_text7,table_text8,table_text9,table_text10;
    private TextView linear_text1,linear_text2,linear_text3,
            linear_text4,linear_text5,linear_text6;
    private EditText table_edit1,table_edit2,table_edit3,table_edit4,table_edit5,
            table_edit6,table_edit7,table_edit8,table_edit9,table_edit10;
    private ListView base_list;

    public APPBaseFragment(Context context, AttributeSet attrs, int defStyle){
        super(context,attrs,defStyle);
        initView(context);
    }

    public void initView(Context context){
        View.inflate(context, R.layout.fragment_app_base,this);
        base_list=(ListView)findViewById(R.id.base_list);
        base_scroll=(ScrollView)findViewById(R.id.base_scroll);

        table_edit1=(EditText)findViewById(R.id.base_table_edit1);
        table_edit2=(EditText)findViewById(R.id.base_table_edit2);
        table_edit3=(EditText)findViewById(R.id.base_table_edit3);
        table_edit4=(EditText)findViewById(R.id.base_table_edit4);
        table_edit5=(EditText)findViewById(R.id.base_table_edit5);
        table_edit6=(EditText)findViewById(R.id.base_table_edit6);
        table_edit7=(EditText)findViewById(R.id.base_table_edit7);
        table_edit8=(EditText)findViewById(R.id.base_table_edit8);
        table_edit9=(EditText)findViewById(R.id.base_table_edit9);
        table_edit10=(EditText)findViewById(R.id.base_table_edit10);

        linear_text1=(TextView)findViewById(R.id.base_linear_text1);
        linear_text2=(TextView)findViewById(R.id.base_linear_text2);
        linear_text3=(TextView)findViewById(R.id.base_linear_text3);
        linear_text4=(TextView)findViewById(R.id.base_linear_text4);
        linear_text5=(TextView)findViewById(R.id.base_linear_text5);
        linear_text6=(TextView)findViewById(R.id.base_linear_text6);

        table_text1=(TextView)findViewById(R.id.base_table_text1);
        table_text2=(TextView)findViewById(R.id.base_table_text2);
        table_text3=(TextView)findViewById(R.id.base_table_text3);
        table_text4=(TextView)findViewById(R.id.base_table_text4);
        table_text5=(TextView)findViewById(R.id.base_table_text5);
        table_text6=(TextView)findViewById(R.id.base_table_text6);
        table_text7=(TextView)findViewById(R.id.base_table_text7);
        table_text8=(TextView)findViewById(R.id.base_table_text8);
        table_text9=(TextView)findViewById(R.id.base_table_text9);
        table_text10=(TextView)findViewById(R.id.base_table_text10);
    }

    public APPBaseFragment(Context context, AttributeSet attrs){
        super(context,attrs);
        initView(context);
    }

    public APPBaseFragment(Context context){
        super(context);
        initView(context);
    }


}
