package com.thb.ws;

import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.thb.app.R;
import com.thb.ui.TableHorizontalScrollView;
import com.thb.ui.TableListView;
import com.zebra.adc.decoder.Barcode2DWithSoft;

import org.ksoap2.serialization.SoapObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TestActivity extends AppCompatActivity {

    private TableListView mLeft;
    private LeftAdapter mLeftAdapter;

    private TableListView mData;
    private DataAdapter mDataAdapter;

    private TableHorizontalScrollView mHeaderHorizontal;
    private TableHorizontalScrollView mDataHorizontal;

    private List<String> mListData;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        initView();
    }

    private void initView(){
        mLeft=findViewById(R.id.lv_left);
        mData=findViewById(R.id.lv_data);
        mHeaderHorizontal=findViewById(R.id.data_horizontal);
        mDataHorizontal=findViewById(R.id.header_horizontal);

        mDataHorizontal.setScrollView(mHeaderHorizontal);
        mHeaderHorizontal.setScrollView(mDataHorizontal);

        mListData=new ArrayList<>();

        mListData.add("11");
        mListData.add("13");
        mListData.add("8");
        mListData.add("9");
        mListData.add("10");
        mListData.add("11");
        mListData.add("12");
        mListData.add("13");
        mListData.add("14");
        mListData.add("15");
        mListData.add("16");
        mListData.add("17");
        mListData.add("18");
        mListData.add("19");

        mLeftAdapter=new LeftAdapter();
        mLeft.setAdapter(mLeftAdapter);

        mDataAdapter=new DataAdapter();
        mData.setAdapter(mDataAdapter);
    }

    class LeftAdapter extends BaseAdapter{
        @Override
        public int getCount(){
            return mListData.size();
        }

        @Override
        public Object getItem(int position){
            return mListData.get(position);
        }

        @Override
        public long getItemId(int position){
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            ViewHolder holder=null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView= LayoutInflater.from(TestActivity.this).inflate(R.layout.table_list_row,null);
                holder.tvLeft=convertView.findViewById(R.id.tv_left);
                convertView.setTag(holder);
            }else {
                holder=(ViewHolder)convertView.getTag();
            }
            int No=position+1;
            holder.tvLeft.setText("第"+No+"行");
            return convertView;
        }

        class ViewHolder{
            TextView tvLeft;
        }
    }

    class DataAdapter extends BaseAdapter{
        @Override
        public int getCount(){
            return mListData.size();
        }

        @Override
        public Object getItem(int position){
            return mListData.get(position);
        }

        @Override
        public long getItemId(int position){
            return position;
        }

        @Override
        public View getView(int position,View convertView,ViewGroup parent){
            ViewHolder holder=null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView=LayoutInflater.from(TestActivity.this).inflate(R.layout.table_item,null);
                holder.tvData=convertView.findViewById(R.id.tv_data);
                holder.linContent=convertView.findViewById(R.id.lin_content);
                convertView.setTag(holder);
            }else{
                holder=(ViewHolder)convertView.getTag();
            }
            return convertView;
        }

        class ViewHolder{
            TextView tvData;
            LinearLayout linContent;
        }
    }
}
