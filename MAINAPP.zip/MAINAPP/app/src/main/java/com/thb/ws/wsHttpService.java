package com.thb.ws;

import android.util.Log;
import android.widget.EditText;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.http.RequestParams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Created by sea79 on 2017/11/1.
 */

public class wsHttpService {

    final static String DEBUG_TAG = "TestSoapService";
    public static final String URL="http://192.168.9.91/BaanWebService/BaanWebService.asmx?op=GetBOM";



    public String CallHttpService(Map<String,String> params){
        String out_str="";
        StringBuilder sb=new StringBuilder();

        try{
            URL url=new URL("http://192.168.9.91/BaanWebService/BaanWebService.asmx?op=GetBOM");
            HttpURLConnection httpconn=(HttpURLConnection)url.openConnection();

            httpconn.setReadTimeout(5000);
            httpconn.setConnectTimeout(5000);
            httpconn.setDoInput(true);
            httpconn.setDoOutput(true);
            httpconn.setRequestMethod("POST");
            httpconn.setInstanceFollowRedirects(true);

            OutputStream outputStream=httpconn.getOutputStream();
            //InputStream inputStream=httpconn.getInputStream();

            BufferedWriter writer=new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            writer.write(getString(params));
            writer.flush();
            writer.close();
            outputStream.close();

           if(httpconn.getResponseCode()==HttpURLConnection.HTTP_OK){
               BufferedReader reader=new BufferedReader(new InputStreamReader(httpconn.getInputStream()));
               String temp;
               while((temp=reader.readLine())!=null){
                   sb.append(temp);
               }
               reader.close();
           }else{
               return "conn error:"+httpconn.getResponseCode();
           }
           httpconn.disconnect();
        }catch (Exception e){
            return e.toString();
        }
        Log.d("******result:****",sb.toString());
        return sb.toString();


    }

    private String getString(Map<String,String> map) throws UnsupportedEncodingException{
        StringBuilder sb=new StringBuilder();
        boolean isFirst=true;

        for(Map.Entry<String,String> entry:map.entrySet()){
            if(isFirst)
                isFirst=false;
            else
                sb.append("&");

            sb.append(URLEncoder.encode(entry.getKey(),"UTF-8"));
            sb.append("=");
            sb.append(URLEncoder.encode(entry.getValue(),"UTF-8"));
        }
        return sb.toString();
    }


}
