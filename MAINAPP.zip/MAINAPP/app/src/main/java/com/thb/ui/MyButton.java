package com.thb.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.widget.AppCompatButton;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.Toast;

import com.thb.ws.BaanSoapService;
import com.thb.ws.TestPub;
import com.thb.ws.TestSoapService;

import java.util.HashMap;

/**
 * Created by sea79 on 2017/10/30.
 */

public class MyButton extends AppCompatButton{
    private Context mContext;
    private MyButton.OnMyButtonListener listener;

    /**
     * dll函数
     */
    //private String strDllName;

    /**
     * 传入Json String
     */
    private String strJson;

    //public TestPub service;
    /**
     * 传入SQL语句
     */
    private String mSQL;

    /**
     *传入HashMap
     */
    private HashMap<String,String> out_HashMap;


    public BaanSoapService service;

    public MyButton(Context context){
        super(context);
        mContext=context;
    }

    public MyButton(Context context, AttributeSet attrs){
        super(context,attrs);
        mContext=context;
    }

    public MyButton(Context context,AttributeSet attrs,int defStyleAttr){
        super(context,attrs,defStyleAttr);
        mContext=context;
    }

    public void setOnMyButtonListener(MyButton.OnMyButtonListener listener){
        this.listener=listener;
    }

    public void setOut_HashMap(HashMap<String,String> out_HashMap){
        this.out_HashMap=out_HashMap;
    }
    //public void setDllname(String strDllName){
    //    this.strDllName=strDllName;
    //}

    //public void setJson(String strJson){
    //    this.strJson=strJson;
    //}

    @Override
    public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP){
            if(listener!=null){
                listener.OnMyButtonGetParameter();
            }

            if(!TextUtils.isEmpty(getText())){
                final ProgressDialog dialog=new ProgressDialog(mContext);
                dialog.show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        try{
                            if(service==null){
                                service=new BaanSoapService();
                            }
                           // service.CallWS(strDllName,"WSJson.invoke",strJson,myPostHandler);
                        }catch (Exception e){
                            Toast.makeText(mContext,e.getMessage(),Toast.LENGTH_LONG).show();
                        }finally {
                            dialog.dismiss();
                        }
                        Looper.loop();
                    }
                }).start();
            }
        }    return super.onTouchEvent(event);
    }

    private Handler myPostHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            //Looper.prepare();
            Bundle b=msg.getData();
            String result=b.getString("Result");
            try{
                listener.OnFinish(result);
            }catch (Exception e){
                Toast.makeText(mContext,e.getMessage(),Toast.LENGTH_LONG).show();
            }finally {

            }
            //Looper.loop();
        }
    };

    /**
     * 回调接口
     */
    public interface OnMyButtonListener{
        /**
         * 执行完毕后回调
         */
        void OnFinish(String strResult);

        /**
         * 获取Button要调用的函数
         */
        void OnMyButtonGetParameter();
    }

}
