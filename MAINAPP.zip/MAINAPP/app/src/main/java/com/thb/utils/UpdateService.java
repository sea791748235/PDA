package com.thb.utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

/**
 * Created by sea79 on 2017/10/30.
 */

public class UpdateService {
    ProgressDialog progressDialog;
    Handler handler;
    Context context;
    UpdateBean updateBean;
    private String url="http://192.168.xx.xx/APK";

    public UpdateBean getUpdateBean() throws Exception{
        String path=url+"/update.txt";
        StringBuffer sb=new StringBuffer();
        String line=null;
        BufferedReader reader=null;
        try{
            //创建URL对象
            URL url=new URL(path);
            //创建HttpURLConnection对象
            HttpURLConnection urlConnection=(HttpURLConnection) url.openConnection();
            //通过HttpURLConnection对象，得到InputStream
            reader=new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            //使用IO流读取文件
            while ((line=reader.readLine())!=null){
                sb.append(line);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try{
                if(reader!=null){
                    reader.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        String info=sb.toString();
        UpdateBean updateBean=new UpdateBean();
        updateBean.setVersion(info.split("&")[1]);
        updateBean.setDescription(info.split("&")[2]);
        updateBean.setUrl(info.split("&")[3]);
        this.updateBean=updateBean;
        return updateBean;
    }

    public boolean isNeedUpdate(){
        //获取最新版本号
        String newest_version=updateBean.getVersion();
        //获取当前版本号
        String now_version="";
        try{
            PackageManager pm=context.getPackageManager();
            PackageInfo pi=pm.getPackageInfo(context.getPackageName(),0);
            now_version=pi.versionName;
        }catch (PackageManager.NameNotFoundException e){
            e.printStackTrace();
        }
        if(newest_version.equals(now_version)){
            return false;
        }else {
            return true;
        }
    }

    public void downLoadFile(final String fileUrl, final ProgressDialog fileDialog, android.os.Handler fileHandler){
        progressDialog=fileDialog;
        handler=fileHandler;
        new Thread(){
            public void run(){
                try{
                    URL url=new URL(fileUrl);
                    //HttpURLConnection获取网页数据
                    HttpURLConnection httpConn=(HttpURLConnection)url.openConnection();
                    httpConn.setRequestProperty("Accept-Encoding","identity");
                    httpConn.setRequestMethod("GET");
                    if(httpConn.getResponseCode()==200){
                        int length=httpConn.getContentLength();
                        progressDialog.setMax(length);
                        InputStream is=httpConn.getInputStream();

                        FileOutputStream fileOutputStream=null;
                        if(is!=null){
                            File file=new File(Environment.getExternalStorageDirectory()+"/Test.apk");
                            fileOutputStream=new FileOutputStream(file);
                            byte[] buf=new byte[10];
                            int ch=-1;
                            int process=0;
                            while ((ch=is.read(buf))!=-1){
                                fileOutputStream.write(buf,0,ch);
                                process+=ch;
                                progressDialog.setProgress(process);
                            }
                        }
                        fileOutputStream.flush();
                        if(fileOutputStream!=null){
                            fileOutputStream.close();
                        }
                        download();
                    }else {
                        Log.d("PDA",String.valueOf(httpConn.getResponseCode()));
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private static byte[] readStream(InputStream inputStream) throws Exception{
        ByteArrayOutputStream bout=new ByteArrayOutputStream();
        byte[] buffer=new byte[1024];
        int len=0;
        while ((len=inputStream.read(buffer))!=-1){
            bout.write(buffer,0,len);
        }
        bout.close();
        inputStream.close();
        return bout.toByteArray();
    }

    void download(){
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.cancel();
                update();
            }
        });
    }

    void update(){
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory(),"Test.apk")),"application/vnd.android.package-archive");
        context.startActivity(intent);
    }
}
