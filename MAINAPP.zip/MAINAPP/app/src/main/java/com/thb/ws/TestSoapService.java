package com.thb.ws;

/**
 * Created by sea79 on 2017/10/26.
 */

import android.util.Log;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by sea79 on 2017/10/20.
 */

public class TestSoapService {
    //DEBUG_TAG
    final static String DEBUG_TAG = "TestSoapService";

    //WebService三要素
    final static String URL = "http://192.168.30.49:18083/operate?wsdl";
    final static String NAMESPACE = "http://test.com/";
    final static String METHOD_NAME = "operate";
    private Class<?> cls;
    private HashMap<String, String> out_HashMap=new HashMap<String, String>();

    public String CallWS(HashMap<String, String> out_HashMap) {

        //接受参数
        String in_Json = "";

        try {
            //1.HttpTransportSE对象传输URL,设置响应时间
            HttpTransportSE ht = new HttpTransportSE(URL, 1000);
            ht.debug = true;
            //2.SoapObject对象指定命名空间及方法名
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
            //3.设置传入参数
            Iterator iter = out_HashMap.entrySet().iterator();
            while (iter.hasNext()) {
                HashMap.Entry localEntry = (HashMap.Entry) iter.next();
                request.addProperty((String) localEntry.getKey(), localEntry.getValue());
            }

            Log.d("--TestSoapService输入参数--",out_HashMap.get("barcode"));
            //4.生成调用Webservice方法的SOAP请求信息。
            // 该信息由SoapSerializationEnvelope对象描述
            // 是否为C#程序
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
            envelope.bodyOut = request;
            envelope.dotNet = false;
            //5.使用call方法调用WebService
            ht.call(null, envelope);
            //6.返回in_Json
            if (envelope.getResponse() != null) {
                SoapObject result = (SoapObject) envelope.bodyIn;
                in_Json = result.getProperty("return").toString();
                Log.d("---收到的回复---", in_Json);
            }
        } catch (IOException e) {
            in_Json = "IO错误";
            Log.d("---IO错误---", e.getMessage());
        } catch (XmlPullParserException e) {
            in_Json = "XML解析错误";
            Log.d("---XML解析错误---", e.getMessage());
        }
        return in_Json;
    }
}

