package com.thb.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.thb.app.APPMainActivity;
import com.thb.app.R;
import com.thb.ws.BaanSoapService;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class LOGINMainActivity extends FragmentActivity {

    private String usernameCheck;
    private String passwordCheck;
    private String companyCheck;


    @ViewInject(R.id.login_spinner_company)
    private Spinner spinner_company;
    @ViewInject(R.id.login_edit_username)
    private EditText edit_username;
    @ViewInject(R.id.login_edit_password)
    private EditText edit_password;
    @ViewInject(R.id.login_check_memory)
    private CheckBox check_memory;

    @OnClick(R.id.login_button_login)
    public void loginClick(View v){
        login();


    }

    private int itemNo=0;
    private SharedPreferences sp;
    private SharedPreferences.Editor editor;

    private BaanSoapService service;
    //private WSSoapService service;
    private Handler mHandler;
    private boolean isConn=false;
    private URL url;
    private HttpURLConnection conn=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_main);




        ViewUtils.inject(this);
        //init
        init();
        initSpinner();


        //initHandler();
        //choose company


        //is web connect
        //isWebConn();

        //if(isConn){
       //     Toast.makeText(getApplicationContext(),"未连接服务器",Toast.LENGTH_SHORT).show();
      //  }else {
      //      Toast.makeText(getApplicationContext(),"已连接服务器",Toast.LENGTH_SHORT).show();
      //  }
        //login



    }


    public void login(){

        usernameCheck=edit_username.getText().toString().trim();
        passwordCheck=edit_password.getText().toString().trim();
        companyCheck=spinner_company.getItemAtPosition(itemNo).toString();
        //Toast.makeText(getApplicationContext(),company_check,Toast.LENGTH_LONG).show();


        if(usernameCheck.equals("zhou")&&passwordCheck.equals("123456")&&companyCheck.equals("191")){
            if(check_memory.isChecked()){
                editor.putString("info_username",usernameCheck);
                editor.putString("info_password",passwordCheck);
                //editor.putString("info_company",itemNo);
                //editor.putString("info_company",itemNo+"");
                editor.commit();
            }else{
                editor.remove("info_username");
                editor.remove("info_password");
                //editor.remove("info_company");
                editor.commit();
            }

            Toast.makeText(getApplicationContext(),"登陆成功", Toast.LENGTH_SHORT).show();
            //startActivity(new Intent(LOGINMainActivity.this,APPMainActivity.class));


            Bundle bundle=new Bundle();
            bundle.putString("usernameCheck",usernameCheck);
            bundle.putString("passwordCheck",passwordCheck);
            bundle.putString("companyCheck",companyCheck);
            Intent intent=new Intent(LOGINMainActivity.this, APPMainActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);


        }else{
            editor.remove("info_username");
            editor.remove("info_password");
            //editor.remove("info_company");
            editor.commit();
            Toast.makeText(getApplicationContext(),"登陆失败", Toast.LENGTH_SHORT).show();

        }
    }


    /**
     * webservice服务端登陆验证
     */

    /*
    private void initHandler(){
        mHandler=new Handler(){
            @Override
            public void handleMessage(Message msg){
                switch (msg.what){
                    case 1:
                        Toast.makeText(LOGINMainActivity.this,"验证成功",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LOGINMainActivity.this,APPMainActivity.class));
                        break;
                    default:
                        Toast.makeText(LOGINMainActivity.this,"验证失败",Toast.LENGTH_SHORT).show();
                        break;
                }
            }

        };
    }
    */


    //public void login(View v){
        //service.setMethodName("login");
        //HashMap<String,String> paramsMap=new HashMap<String,String>();
        //paramsMap.put("account",edit_account.getText().toString().trim());
       // paramsMap.put("password",edit_password.getText().toString().trim());
      //  service.setParams(paramsMap);

        /*
        new Thread(new Runnable() {
            @Override
            public void run() {
                Message msg=new Message();
                msg.what=0;
                try{
                    //String resultJson = service.invoke();
                    //System.out.println(resultJson);

                   // if(resultJson==null){

                   // }
                    //WSCommandBean command= WSJsonOperator.json2Bean(resultJson,WSCommandBean.class);
                    //msg.what=new Integer(command.getStatus());
                   // msg.obj=command.getErrmsg();
                    mHandler.sendMessage(msg);
                }catch (XmlPullParserException e){
                    e.printStackTrace();
                    msg.what=-1;

                }catch (IOException e){
                    e.printStackTrace();
                    msg.what=-2;
                }
            }
        }).start();
        */


    public void test(){


    }

    public void exit(){
        finish();
        System.exit(0);
    }



    public void init(){

        sp=getSharedPreferences("info",MODE_PRIVATE);
        editor=sp.edit();

        String username=sp.getString("info_username","");
        String password=sp.getString("info_password","");

        if(username.equals("") || password.equals("")){
            check_memory.setChecked(false);
        }else{
            edit_username.setText(username);
            edit_password.setText(password);
            check_memory.setChecked(true);
        }
    }


    /**
     * 初始化Spinner控件
     */

    public void initSpinner(){

        //建立数据源
        final String[] spinner_items=getResources().getStringArray(R.array.spinnerItems);
        //建立adapter绑定数据源
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item,spinner_items);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //绑定控件
        spinner_company.setAdapter(arrayAdapter);
        spinner_company.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] spinner_items = getResources().getStringArray(R.array.spinnerItems);
                itemNo=i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    /**
     * ping服务器测试是否连接
     * @return
     */
    public boolean isWebConn(){

        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    url=new URL("http://192.168.30.49");
                    conn=(HttpURLConnection)url.openConnection();
                    conn.setConnectTimeout(1000*5);
                    if(conn.getResponseCode()==200){
                        isConn=true;
                    }
                }catch (MalformedURLException e){
                    e.printStackTrace();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();

        return isConn;
    }
}