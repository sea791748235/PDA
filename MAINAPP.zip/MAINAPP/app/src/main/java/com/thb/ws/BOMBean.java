package com.thb.ws;

/**
 * Created by sea79 on 2017/11/3.
 */

public class BOMBean {
    private String T$MITM;
    private String T$UNOM;
    private String T$PONO;
    private String T$SITM;
    private String T$QANA;
    private String T$SCPF;
    private String T$SCPQ;
    private String T$INDT;
    private String T$EXDT;

    public String getT$MITM(){
        return T$MITM;
    }

    public void setT$MITM(String T$MITM){
        this.T$MITM=T$MITM;

    }

    public String getT$UNOM(){
        return T$UNOM;
    }

    public void setT$UNOM(String T$UNOM){
        this.T$UNOM=T$UNOM;

    }
    public String getT$PONO(){
        return T$PONO;
    }

    public void setT$PONO(String T$PONO){
        this.T$PONO=T$PONO;

    }
    public String getT$SITM(){
        return T$SITM;
    }

    public void setT$SITM(String T$SITM){
        this.T$SITM=T$SITM;

    }
    public String getT$QANA(){
        return T$QANA;
    }

    public void setT$QANA(String T$QANA){
        this.T$QANA=T$QANA;

    }
    public String getT$INDT(){
        return T$INDT;
    }

    public void setT$INDT(String T$INDT){
        this.T$INDT=T$INDT;

    }

    public String getT$EXDT(){
        return T$EXDT;
    }

    public void setT$EXDT(String T$EXDT){
        this.T$EXDT=T$EXDT;

    }

    public String getT$SCPF(){
        return T$SCPF;
    }

    public void setT$SCPF(String T$SCPF){
        this.T$SCPF=T$SCPF;

    }
    public String getT$SCPQ(){
        return T$SCPQ;
    }

    public void setT$SCPQ(String T$SCPQ){
        this.T$SCPQ=T$SCPQ;

    }
}
