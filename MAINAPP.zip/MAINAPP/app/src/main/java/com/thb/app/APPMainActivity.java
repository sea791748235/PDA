package com.thb.app;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class APPMainActivity extends AppCompatActivity {

    private String username;
    private String password;
    private String company;


    public String getUsername(){
        return username;
    }
    public void setUsername(String username){
        this.username=username;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        this.password=password;
    }
    public String getCompany(){
        return company;
    }
    public void setCompany(String company){
        this.company=company;
    }


    private TabLayout tabTop;
    private ViewPager viewPager;
    private HorizontalScrollView tabBottom;

    private List<Fragment> list;
    private MyAdapter adapter;
    private String[] titles = {"扫码上架", "整箱转移", "散箱转移", "扫码盘点",
            "销售出库", "扫码报工","包装检验","整箱库位转移",
            "散箱库位转移","设置"};
    private int images[] = {R.mipmap.ic_smsz_white_24dp,R.mipmap.ic_zxzy_white_24dp,R.mipmap.ic_sxzy_white_24dp,R.mipmap.ic_smpd_white_24dp,
            R.mipmap.ic_xsck_white_24dp, R.mipmap.ic_smbg_white_24dp,R.mipmap.ic_bzjy_white_24dp,R.mipmap.ic_zxkwzy_white_24dp,
    R.mipmap.ic_sxkwzy_white_24dp,R.mipmap.ic_sz_white_24dp};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_main);
        //实例化
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        tabTop = (TabLayout) findViewById(R.id.tabtop);

        //getTabBottomView();
        //页面，数据源
        list = new ArrayList<>();
        list.add(new APPTab1Fragment());
        list.add(new APPTab2Fragment());
        list.add(new APPTab3Fragment());
        list.add(new APPTab4Fragment());
        list.add(new APPTab5Fragment());
        list.add(new APPTab6Fragment());
        //ViewPager的适配器
        adapter = new MyAdapter(getSupportFragmentManager(), this);
        viewPager.setAdapter(adapter);
        //绑定
        tabTop.setupWithViewPager(viewPager);

        //设置自定义视图
        for (int i = 0; i < tabTop.getTabCount(); i++) {
            TabLayout.Tab tab = tabTop.getTabAt(i);
            tab.setCustomView(adapter.getTabView(i));
        }

        //Bundle bundle=this.getIntent().getExtras();
        //setUsername(bundle.getString("usernameCheck"));
        //setPassword(bundle.getString("passwordCheck"));
        //setCompany(bundle.getString("companyCheck"));

    }

/*
    private void getTabBottomView() {
        tabBottom = (HorizontalScrollView) findViewById(R.id.tabbottom_scroll);
        Button button1 = (Button) findViewById(R.id.tabbottom_button1);
        Button button2 = (Button) findViewById(R.id.tabbottom_button2);
        Button button3 = (Button) findViewById(R.id.tabbottom_button3);
        Button button4 = (Button) findViewById(R.id.tabbottom_button4);
        Button button5 = (Button) findViewById(R.id.tabbottom_button5);
        Button button6 = (Button) findViewById(R.id.tabbottom_button6);

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(APPMainActivity.this, LOGINMainActivity.class));
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), com.thb.qr.QRMainActivity.class));
                Toast.makeText(APPMainActivity.this, "click button1", Toast.LENGTH_SHORT).show();
            }
        });
    }
*/


    class MyAdapter extends FragmentPagerAdapter {

        private Context context;

        public MyAdapter(FragmentManager fm, Context context) {
            super(fm);
            this.context = context;
        }

        @Override
        public Fragment getItem(int position) {
            return list.get(position);
        }

        @Override
        public int getCount() {
            return list.size();
        }

        /**
         * 自定义方法，提供自定义Tab
         *
         * @param position 位置
         * @return 返回Tab的View
         */
        public View getTabView(int position) {
            View v = LayoutInflater.from(context).inflate(R.layout.tabtop_custom, null);
            TextView textView = (TextView) v.findViewById(R.id.tv_title);
            ImageView imageView = (ImageView) v.findViewById(R.id.iv_icon);
            textView.setText(titles[position]);
            imageView.setImageResource(images[position]);
            //添加一行，设置颜色
            textView.setTextColor(tabTop.getTabTextColors());//
            return v;
        }


    }
}