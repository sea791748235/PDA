package com.thb.app;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.thb.ws.BOMBean;
import com.thb.ws.BaanJsonOperator;
import com.thb.ws.BaanSoapService;
import com.zebra.adc.decoder.Barcode2DWithSoft;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the

 * to handle interaction events.
 * Use the {@link APPTab6Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class APPTab6Fragment extends Fragment {

    private Barcode2DWithSoft mReader;
    private String scanResult;

    private EditText edit1;
    private EditText edit2;
    private EditText edit3;
    private EditText edit4;

    private Button button1;
    private Button button2;
    private Button button3;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;



    public APPTab6Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment APPTab6Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static APPTab6Fragment newInstance(String param1, String param2) {
        APPTab6Fragment fragment = new APPTab6Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectLeakedSqlLiteObjects().detectLeakedClosableObjects().penaltyLog().penaltyDeath().build());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view=inflater.inflate(R.layout.fragment_app_tab6,container,false);

        edit1=view.findViewById(R.id.tab6_table_edit1);
        edit3=view.findViewById(R.id.tab6_table_edit3);
        edit2=view.findViewById(R.id.tab6_table_edit2);
        edit4=view.findViewById(R.id.tab6_table_edit4);

        button2=view.findViewById(R.id.tab6_button2);
        button1=view.findViewById(R.id.tab6_button1);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doReOrCo();
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doBaan();
            }
        });

        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onDetach() {
        super.onDetach();

    }

    public void doScan(){

        mReader=Barcode2DWithSoft.getInstance();
        mReader.open(getActivity());
        mReader.setParameter(324,1);
        mReader.setParameter(300,0);
        mReader.setParameter(361,0);
        mReader.scan();
    }

    public Barcode2DWithSoft.ScanCallback mScanCallback=new Barcode2DWithSoft.ScanCallback() {
        @Override
        public void onScanComplete(int i, int i1, byte[] bytes) {
            if(i1<1){
                edit1.setText("扫描失败");
            }else {
                scanResult=new String(bytes);
                edit1.setText(scanResult);
            }
            mReader.stopScan();
        }
    };

    public void doDecode(){
        mReader.setScanCallback(mScanCallback);
    }

    public void doReOrCo(){
        String method="ReportOrdersCompleted";
        HashMap<String,String> activitionMap=new HashMap<String,String>();
        HashMap<String,String> paramsMap=new HashMap<>();

        //activitionMap.put("username",((APPMainActivity)getActivity()).getUsername());
        //activitionMap.put("password",((APPMainActivity)getActivity()).getPassword());
        //activitionMap.put("company",((APPMainActivity)getActivity()).getCompany());

        paramsMap.put("Unique","1111111111");
        paramsMap.put("ProductionOrder","222222222222");
        paramsMap.put("QuantityToDeliver","33333333333");
        paramsMap.put("LotCode","444444444444");

        Log.e("******body******",paramsMap.get("ProductionOrder"));
        Log.e("******body******",paramsMap.get("QuantityToDeliver"));
        Log.e("******body******",paramsMap.get("Unique"));
        //Log.e("******head******",activitionMap.get("username"));
       // Log.e("******head******",activitionMap.get("password"));
      // Log.e("******head******",activitionMap.get("company"));

        BaanSoapService service=new BaanSoapService();
        String resultStr=service.CallWSInComplex(paramsMap,method);
        edit3.setText(resultStr);
    }

    public void doBaan(){
        String method="ReportOrdersCompleted";
        HashMap<String,String> activationMap=new HashMap<String,String>();
        HashMap<String,String> paramsMap=new HashMap<>();

        activationMap.put("username","zhou");
        activationMap.put("password","123456");
        activationMap.put("company","191");

        paramsMap.put("Unique",edit4.getText().toString().trim());
        paramsMap.put("ProductionOrder","DD1000061");
        paramsMap.put("QuantityToDeliver","2");
        //paramsMap.put("LotCode","44");

        Log.e("******body******",paramsMap.get("ProductionOrder"));
        Log.e("******body******",paramsMap.get("QuantityToDeliver"));
        Log.e("******body******",paramsMap.get("Unique"));
        //Log.e("******head******",activitionMap.get("username"));
        // Log.e("******head******",activitionMap.get("password"));
        // Log.e("******head******",activitionMap.get("company"));

        BaanSoapService service=new BaanSoapService();
        String resultStr=service.CallBaanWS(activationMap,paramsMap,method);
        edit3.setText(resultStr);
    }



    public void doClear(){

        edit1.setText("");
        edit2.setText("");
        edit3.setText("");
        edit4.setText("");

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */

}
