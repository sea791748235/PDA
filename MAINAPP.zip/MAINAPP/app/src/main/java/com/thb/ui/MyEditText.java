package com.thb.ui;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.EditText;

import com.thb.app.R;
import com.thb.ws.TestPub;

/**
 * Created by sea79 on 2017/10/30.
 */

public class MyEditText extends AppCompatEditText {
    private final static String TAG="EditTextWithDel";
    private Drawable imgInable;
    private Drawable imgAble;
    private Context mContext;
    /**
     * 获取传入SQL
     */
    private String mSQL;

    //private OnMyEditTextListener listener;
    public TestPub pub;

    public MyEditText(Context context){
        super(context);
        mContext=context;
        init();
    }

    public MyEditText(Context context, AttributeSet attrs,int defStyle){
        super(context);
        mContext=context;
        init();
    }

    public MyEditText(Context context,AttributeSet attrs){
        super(context);
        mContext=context;
        init();
    }

    public String getSQL(){
        return mSQL;
    }

    public void setSQL(String mSQL){
        this.mSQL=mSQL;
    }

    //public OnMyEditTextListener getListener(){
    //    return listener;
   // }

    //public void setOnMyEditTextListener(OnMyEditTextListener listener){
     //   this.listener=listener;
  //  }

    private void init(){
        imgInable=mContext.getResources().getDrawable(R.mipmap.delete_gray);
        imgAble=mContext.getResources().getDrawable(R.mipmap.delete);
        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
               setDrawable();
            }
        });
        setDrawable();
    }

    //设置删除图片
    private void setDrawable(){
        if(length()<1){
            setCompoundDrawablesWithIntrinsicBounds(null,null,imgInable,null);
            setCompoundDrawablesWithIntrinsicBounds(null,null,imgAble,null);
        }
    }

    //处理删除事件
    @Override
    public boolean onTouchEvent(MotionEvent event){
        if(imgAble!=null&&event.getAction()==MotionEvent.ACTION_UP){
            int eventX=(int)event.getRawX();
            int eventY=(int)event.getRawY();
            Rect rect=new Rect();
            getGlobalVisibleRect(rect);
            rect.left=rect.right-50;
            if(rect.contains(eventX,eventY))
                setText("");
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void finalize() throws Throwable{
        super.finalize();
    }

    @Override
    protected void onFocusChanged(boolean focused,int direction,Rect previouslyFocuseRect){
        super.onFocusChanged(focused,direction,previouslyFocuseRect);
        if(focused){
            //得到焦点进行处理
            this.selectAll();
        }else{
            //if(listener!=null){
                //listener.OnMyEditTextGetSQL();
           // }
        }
    }


}
